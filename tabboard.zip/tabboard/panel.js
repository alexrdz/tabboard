let tabs = [];
let dragSrcIndex = null;

// ── Boot ─────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  await loadTabs();
  await renderProjectOptions();

  document.getElementById('btn-refresh').addEventListener('click', loadTabs);
  document.getElementById('btn-save').addEventListener('click', saveProject);
  document.getElementById('btn-delete').addEventListener('click', deleteProject);
  document.getElementById('project-select').addEventListener('change', loadProject);
});

// ── Tab loading ───────────────────────────────────────────────

async function loadTabs() {
  setStatus('Loading…');

  const rawTabs = await chrome.tabs.query({ currentWindow: true });

  tabs = await Promise.all(rawTabs.map(fetchTabData));

  render();
}

async function fetchTabData(tab) {
  let image = null;
  let description = null;

  const isInjectable =
    tab.url &&
    (tab.url.startsWith('http://') || tab.url.startsWith('https://'));

  if (isInjectable) {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractMeta,
      });
      if (result?.result) {
        image = result.result.image;
        description = result.result.description;
      }
    } catch (_) {
      // Restricted page (CSP, chrome-extension://, etc.) — skip silently
    }
  }

  return {
    id: tab.id,
    url: tab.url,
    title: tab.title || tab.url,
    favicon: tab.favIconUrl || null,
    image,
    description,
  };
}

// Runs inside the target tab — must be fully self-contained (no closures)
function extractMeta() {
  function attr(selector, attribute) {
    return document.querySelector(selector)?.[attribute] || null;
  }
  return {
    image:
      attr('meta[property="og:image"]', 'content') ||
      attr('meta[name="twitter:image"]', 'content') ||
      null,
    description:
      attr('meta[property="og:description"]', 'content') ||
      attr('meta[name="description"]', 'content') ||
      null,
  };
}

// ── Rendering ─────────────────────────────────────────────────

function render() {
  const board = document.getElementById('storyboard');
  board.innerHTML = '';

  if (tabs.length === 0) {
    setStatus('No tabs found.');
    return;
  }

  tabs.forEach((tab, index) => {
    board.appendChild(makeCard(tab, index));
  });
}

function makeCard(tab, index) {
  const card = document.createElement('div');
  card.className = 'card' + (tab.id ? ' is-live' : '');
  card.draggable = true;
  card.dataset.index = index;

  // Image / placeholder
  if (tab.image) {
    const img = document.createElement('img');
    img.className = 'card-image';
    img.src = tab.image;
    img.alt = '';
    img.addEventListener('error', () => img.replaceWith(makePlaceholder()));
    card.appendChild(img);
  } else {
    card.appendChild(makePlaceholder());
  }

  // Body
  const body = document.createElement('div');
  body.className = 'card-body';

  const titleRow = document.createElement('div');
  titleRow.className = 'card-title-row';

  if (tab.favicon) {
    const fav = document.createElement('img');
    fav.className = 'favicon';
    fav.src = tab.favicon;
    fav.alt = '';
    fav.addEventListener('error', () => fav.remove());
    titleRow.appendChild(fav);
  }

  const title = document.createElement('span');
  title.className = 'card-title';
  title.textContent = tab.title;
  title.title = tab.title;
  titleRow.appendChild(title);
  body.appendChild(titleRow);

  if (tab.description) {
    const desc = document.createElement('p');
    desc.className = 'card-desc';
    desc.textContent = tab.description;
    body.appendChild(desc);
  }

  card.appendChild(body);

  // Drag and drop
  card.addEventListener('dragstart', (e) => {
    dragSrcIndex = index;
    e.dataTransfer.effectAllowed = 'move';
    requestAnimationFrame(() => card.classList.add('dragging'));
  });

  card.addEventListener('dragend', () => {
    card.classList.remove('dragging');
    board().querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
  });

  card.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    board().querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
    card.classList.add('drag-over');
  });

  card.addEventListener('drop', (e) => {
    e.preventDefault();
    card.classList.remove('drag-over');
    if (dragSrcIndex === null || dragSrcIndex === index) return;
    const [moved] = tabs.splice(dragSrcIndex, 1);
    tabs.splice(index, 0, moved);
    dragSrcIndex = null;
    render();
  });

  // Click to switch to tab (live tabs only, not saved project tabs)
  if (tab.id) {
    card.addEventListener('click', () => {
      chrome.tabs.update(tab.id, { active: true });
    });
  }

  return card;
}

function makePlaceholder() {
  const div = document.createElement('div');
  div.className = 'card-image-placeholder';
  return div;
}

function setStatus(msg) {
  const b = board();
  b.innerHTML = '';
  const p = document.createElement('p');
  p.className = 'status-msg';
  p.textContent = msg;
  b.appendChild(p);
}

function board() {
  return document.getElementById('storyboard');
}

// ── Projects ──────────────────────────────────────────────────

async function saveProject() {
  const nameEl = document.getElementById('project-name');
  const name = nameEl.value.trim();
  if (!name) {
    nameEl.focus();
    return;
  }

  const { projects = {} } = await chrome.storage.local.get('projects');
  projects[name] = tabs.map(({ url, title, favicon, image, description }) => ({
    url, title, favicon, image, description,
  }));
  await chrome.storage.local.set({ projects });
  await renderProjectOptions(name);
}

async function loadProject() {
  const name = document.getElementById('project-select').value;
  if (!name) return;

  const { projects = {} } = await chrome.storage.local.get('projects');
  const saved = projects[name];
  if (!saved) return;

  // Saved tabs have no live id — cards won't navigate on click
  tabs = saved.map(t => ({ ...t, id: null }));
  render();
}

async function deleteProject() {
  const select = document.getElementById('project-select');
  const name = select.value;
  if (!name) return;

  const { projects = {} } = await chrome.storage.local.get('projects');
  delete projects[name];
  await chrome.storage.local.set({ projects });
  await renderProjectOptions();
}

async function renderProjectOptions(selected = '') {
  const { projects = {} } = await chrome.storage.local.get('projects');
  const select = document.getElementById('project-select');
  select.innerHTML = '<option value="">Load saved project…</option>';
  for (const name of Object.keys(projects).sort()) {
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    if (name === selected) opt.selected = true;
    select.appendChild(opt);
  }
}


    document.querySelectorAll('.card').forEach(card => {
      card.addEventListener('dragstart', () => card.classList.add('dragging'));
      card.addEventListener('dragend', () => card.classList.remove('dragging'));
    });

    const refreshBtn = document.getElementById('btn-refresh');
    refreshBtn.addEventListener('click', () => {
      refreshBtn.style.transform = 'rotate(180deg)';
      setTimeout(() => { refreshBtn.style.transform = ''; }, 300);
    });
