# TabBoard

TabBoard is a Chrome extension that provides a tab collection of your open tabs in the browser's side panel. With a clean design, it allows you to drag to reorder tabs, save your current tab configurations as named projects.

## Features

- **Visual Interface**: See your open tabs presented as beautiful, easy-to-read cards in the Chrome side panel.
- **Rich Metadata Extraction**: Automatically fetches Open Graph images (`og:image`), descriptions, and favicons from your active tabs to provide a highly visual snapshot of each page.
- **Drag & Drop**: Easily reorganize your tabs by dragging and dropping the cards seamlessly.
- **Project Management**: Save your current set of tabs into "Projects". This allows you to quickly switch contexts between different workflows or research topics. Load saved projects or delete them when they are no longer needed.
- **Quick Navigation**: Click on any live tab card to instantly switch to that tab in your browser.
- **Modern Aesthetics**: A beautifully designed user interface featuring fluid spacing, a Notion-inspired palette, subtle character gradients, and smooth interactions.

## Installation

Since this extension is loaded locally for development, follow these steps to install it in Google Chrome:

1. Open Chrome and navigate to `chrome://extensions/`.
2. Enable **Developer mode** by toggling the switch in the top right corner.
3. Click the **Load unpacked** button in the top left.
4. Select the `tabboard` folder containing this source code.
5. The extension is now installed. You can open it by clicking the Chrome Side Panel icon and selecting **TabBoard** from the dropdown menu, or by pinning the extension icon to your toolbar.

## Structure

- `manifest.json`: Configuration and permissions for the Chrome extension (requires `tabs`, `storage`, `scripting`, and `sidePanel`).
- `background.js`: Service worker managing the side panel behavior.
- `panel.html` & `panel.js`: The visual frontend and application logic for rendering your tabs and handling drag-and-drop actions.
- `panel.css`: Previously used for styling (the UI is currently maintained within `panel.html`'s inline `<style>` tag).

## Development

- **Tab Fetching**: `panel.js` queries `chrome.tabs`, then injects a script via `chrome.scripting` into valid pages to pull rich metadata.
- **Storage**: Uses `chrome.storage.local` to safely save and retrieve your custom project boards.
